#!/bin/bash

str="Hello, World, CentOS!"
echo "${str:(-7):4}"
