#!/bin/bash

str="Hello, World, CentOS!"
echo $str | cut -c 8-12
